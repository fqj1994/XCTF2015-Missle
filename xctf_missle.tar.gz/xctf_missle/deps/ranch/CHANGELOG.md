CHANGELOG
=========

1.1.0
-----

 *  Add Transport:secure/0

 *  Add SSL partial_chain option

 *  Stop reporting errors on {error, closed} in accept_ack

1.0.0
-----

 *  Initial release.
