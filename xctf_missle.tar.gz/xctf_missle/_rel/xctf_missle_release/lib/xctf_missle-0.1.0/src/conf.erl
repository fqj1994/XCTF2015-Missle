-module(conf).

-compile([export_all]).

dbuser() ->
    "missles".

dbpass() ->
    "".
